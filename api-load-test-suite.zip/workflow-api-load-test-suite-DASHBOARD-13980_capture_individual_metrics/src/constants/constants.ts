const businessKey = "c2db266c-80fd-4225-b6f6-9d626685219d";
const processDefinitionKey = "intelligence";
const initialStatus = "DRAFT";
const testHarness = true;
const workspaceId = "intelligence";
const nextAction = "UNDER_REVIEW";
const notifyCopyDesk = false;
const withVariablesInReturn = true;

export const START_WORKFLOW_QUERY = {
  operationName: "startProcess",
  variables: {
    dto: {
      businessKey,
      processDefinitionKey,
      variables:{
        initialStatus,
        testHarness,
        workspaceId
      }
    },
  },
  query: `
          mutation startProcess($dto: StartProcessDtoInput!) {
              startProcess(dto: $dto) 
                 {
                        id    
                        definitionId
                        businessKey
                        caseInstanceId
                        ended
                        suspended
                        tenantId
                        variables
                        __typename

                    }
           }
      `,
};

export const WORKFLOW_STATUS_QUERY = {
  operationName: "workflowStatus",
  variables: {
      businessKey,
  },
  query: `
          query workflowStatus($businessKey: String!) {
                workflowStatus(businessKey: $businessKey) {
                      statusCode
                      statusLabel
                      createdOn
                      errorMessage
                      isErrorOccurred
                      __typename
               }
          }
      `,
};


export const WORKFLOW_STAGE_INFO_QUERY = {
  operationName: "workflowStageInfo",
  variables: {
      businessKey,
  },
  query: `
          query workflowStageInfo($businessKey: String!) 
              { workflowStageInfo(businessKey: $businessKey) 
                   {  
                        id
                        name
                        assignee
                        processInstanceId
                        taskDefinitionKey
                        isLockAllowed
                        isEditable
                        nextActions 
                      {
                            key
                            value
                            message
                            isAllowed
                            properties 
                               {
                                    key       
                                    value
                                    __typename
                                  }
                          __typename }
              __typename }
         }
      `,
};

export const WORKFLOW_COMPLETE_TASK_QUERY = (workflow_taskid:any)=>({
  operationName: "completeTask",
  variables: {
    dto: {
      taskId : workflow_taskid,
      variables: {
        nextAction,
        notifyCopyDesk,
        testHarness,
      },
      withVariablesInReturn,
    },
  },
  query: `
             mutation completeTask($dto: CompleteTaskDtoInput!) { 
                  completeTask(dto: $dto) 
                      { 
                         isSuccessful
                         statusCode
                         statusLabel
                         __typename
                       }
              }
          `,
});