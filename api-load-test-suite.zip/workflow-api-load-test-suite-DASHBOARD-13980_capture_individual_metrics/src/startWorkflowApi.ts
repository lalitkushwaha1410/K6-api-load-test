import { check } from "k6";
import { Options } from "k6/options";
import http from "k6/http";
import { Counter } from "k6/metrics";
import { getLoginCookie } from "./login";
import { authoringApiUrl, authoringOrigin, authoringLogin,rateConfigValue } from "./envrionments";
// @ts-ignore
import { htmlReport } from "./javascripts/htmlReportFormat";
import { textSummary } from "./javascripts/index";
import getDate from "./utils/helpers";
import { START_WORKFLOW_QUERY } from "./constants/constants";

var myCounter = new Counter("resultCode");

export let options: Options = {
  scenarios: {
    rateConfigValue
  },
  insecureSkipTLSVerify: true,
  thresholds: {
    http_req_duration: ["p(90) < 1000", "p(95) < 2000", "med<2000"], // med/avg of requests must complete below 1.5s
    http_req_failed: ["rate < 0.01"],
  },
};

// Setup stage - login and set up cookies
export function setup() {
  const cookies: string[] = [];
  for (let user of authoringLogin) {
    const cookie = getLoginCookie(user.user, user.pass);
    if (cookie) {
        cookies.push(cookie);
    }
  }
  return cookies;
}
export default (cookies: string[]) => {
  
  let randomUser = cookies[Math.floor(Math.random() * cookies.length)];
  const cookie = randomUser;
  var params: any = {
    headers: {
      "Content-Type": "application/json",
      cookie: `aauth=${cookie}`,
      "initialStatus":"DRAFT",
      "testHarness":"TRUE",
      "workspaceId":"intelligence",
      "accept-encoding": "gzip, deflate, br",
      Accept: "*/*",
      origin: authoringOrigin,
      "sec-fetch-dest": "empty",
      "sec-fetch-mode": "cors",
      "sec-fetch-site": "same-origin",
      "user-agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36",
    },
  };
  const workflowQuery = START_WORKFLOW_QUERY;
  const res = http.post(
    authoringApiUrl,
    JSON.stringify(workflowQuery),
    params
  );
  const dateMarker = getDate();
  const result = res.status;

  myCounter.add(1, {
    result: `${result}`,
    endTimeStamp: dateMarker.timestamp.toString(),
  });
  check(res, {
    "Start Workflow API status is 200": () => result === 200,
  });
};

export function handleSummary(data: any) {
    return {
      "./results/startWorkflowApi.html": htmlReport(data),
      stdout: textSummary(data, { indent: " ", enableColors: true }),
    };
  }

