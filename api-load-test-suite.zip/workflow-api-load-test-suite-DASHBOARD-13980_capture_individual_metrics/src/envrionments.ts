import { Scenario } from "k6/options";

type Env = "systest" | "performance" | "staging";
type Rate = "1" | "5" | "10" | "20" | "40";

const authoringLogins = [
  {
    user: "cha\\wf_reviewer@cha.rbxd.ds",
    pass: "Passw0rd",
  },
];

const environments = {
  systest: {
    authoringLoginUrl: "https://authoring.systest.cha.rbxd.ds/workflow-test-harness/",
    authoringApiUrl: "https://authoring.systest.cha.rbxd.ds/api/workflow/v1/graphql",
    subscriberApiUrl: "https://subscriber.systest.genesis.cha.rbxd.ds/api/workflow/v1/graphql",
    webhook:"https://authoring.systest.cha.rbxd.ds/api/workflow/v1/webhooks/",
    authoringOrigin: "https://authoring.systest.cha.rbxd.ds",
    referer: "",
    authoringLogins: authoringLogins,
  },
  staging: {
    authoringLoginUrl: "https://authoring.staging.cha.rbxd.ds/workflow-test-harness/",
    authoringApiUrl: "https://authoring.staging.cha.rbxd.ds/api/workflow/v1/graphql",
    subscriberApiUrl: "https://subscriber.staging.genesis.cha.rbxd.ds/api/video/v1/graphql",
    webhook: "https://authoring.staging.cha.rbxd.ds/api/workflow/v1/webhooks/",
    authoringOrigin: "https://authoring.staging.cha.rbxd.ds",
    referer: "",
    authoringLogins: authoringLogins,
  },
  integration: {
    authoringLoginUrl: "https://authoring.integration.cha.rbxd.ds/mfe/video/authoring/",
    authoringApiUrl: "https://authoring.integration.cha.rbxd.ds/api/video/v1/graphql",
    subscriberApiUrl: "https://subscriber.integration.genesis.cha.rbxd.ds/api/video/v1/graphql",
    webhook:"https://authoring.integration.cha.rbxd.ds/api/video/v1/webhooks/",
    authoringOrigin: "https://authoring.integration.cha.rbxd.ds",
    referer: "",
    authoringLogins: authoringLogins,
  },
  performance: {
    authoringLoginUrl: "https://authoring.performance.cha.rbxd.ds/mfe/video/authoring/",
    authoringApiUrl: "https://authoring.performance.cha.rbxd.ds/api/video/v1/graphql",
    subscriberApiUrl: "https://subscriber.performance.genesis.cha.rbxd.ds/api/video/v1/graphql",
    webhook:"https://authoring.performance.cha.rbxd.ds/api/video/v1/webhooks/",
    authoringOrigin: "https://authoring.performance.cha.rbxd.ds",
    referer: "",
    authoringLogins: authoringLogins,
  }
};

interface RateConfig {
  1: Scenario;
  5: Scenario;
  10: Scenario;
  20: Scenario;
  40: Scenario;
}

const loadTestConfig: RateConfig = {
  1: {
    executor: "constant-arrival-rate",
    rate: 1,
    timeUnit: "5s",
    duration: "15s",
    gracefulStop: "5s",
    preAllocatedVUs: 5,
    maxVUs: 5, // double the max rate vu's
  },
  5: {
    executor: "constant-arrival-rate",
    rate: 5,
    timeUnit: "20s",
    duration: "1m",
    gracefulStop: "5s",
    preAllocatedVUs: 15,
    maxVUs: 20, // double the max rate vu's
  },
  10: {
    executor: "constant-arrival-rate",
    rate: 10,
    timeUnit: "30s",
    duration: "2m",
    gracefulStop: "5s",
    preAllocatedVUs: 40,
    maxVUs: 40, // double the max rate vu's
  },
  20: {
    executor: "constant-arrival-rate",
    rate: 20,
    timeUnit: "1m",
    duration: "5m",
    gracefulStop: "5s",
    preAllocatedVUs: 60,
    maxVUs: 60, // double the max rate vu's
  },
  40: {
    executor: "constant-arrival-rate",
    rate: 40,
    timeUnit: "20s",
    duration: "20m",
    gracefulStop: "5s",
    preAllocatedVUs: 45,
    maxVUs: 95, // double the max rate vu's
  },
};

// @ts-ignore
let environment = __ENV.environment as Env;
// @ts-ignore
if (!environment) {
  environment = "systest";
}

// @ts-ignore
let rateConfig = __ENV.rateConfig as Rate;
// @ts-ignore
if (!rateConfig) {
  rateConfig = "1";
}

export const authoringLoginUrl = environments[environment].authoringLoginUrl;
export const authoringApiUrl = environments[environment].authoringApiUrl;
export const subscriberApiUrl = environments[environment].subscriberApiUrl;
export const webhook = environments[environment].webhook;
export const authoringOrigin = environments[environment].authoringOrigin;
export const referer = environments[environment].referer;
export const authoringLogin = environments[environment].authoringLogins;
export const rateConfigValue = loadTestConfig[rateConfig];
